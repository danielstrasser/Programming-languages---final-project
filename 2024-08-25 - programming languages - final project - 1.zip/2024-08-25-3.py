import re

###############################################################################
#                                                                             #
#  LEXER                                                                      #
#                                                                             #
###############################################################################

# Token types
#
# EOF (end-of-file) token is used to indicate that
# there is no more input left for lexical analysis
(ID, INTEGER, BOOLEAN, PLUS, MINUS, MUL, DIV, MOD, LPAREN, RPAREN,
 AND, OR, GT, LT, EQ, NEQ, GTE, LTE, SEMI, RBRACE, LBRACE, IF, THEN, ELSE, ELIF, COMMA, EOF) = (
    'ID', 'INTEGER', 'BOOLEAN', 'PLUS', 'MINUS', 'MUL', 'DIV', 'MOD', '(', ')',
    'AND', 'OR', 'GT', 'LT', 'EQ', 'NEQ', 'GTE', 'LTE', 'SEMI', '{', '}', 'IF', 'THEN', 'ELSE', 'ELIF', 'COMMA', 'EOF'
)
function_table = {}


class Token(object):
    def __init__(self, type, value):
        self.type = type
        self.value = value

    def __str__(self):
        """String representation of the class instance.

        Examples:
            Token(INTEGER, 3)
            Token(PLUS, '+')
            Token(MUL, '*')
        """
        return 'Token({type}, {value})'.format(
            type=self.type,
            value=repr(self.value)
        )

    def __repr__(self):
        return self.__str__()


RESERVED_KEYWORDS = {
    'BEGIN': Token('BEGIN', 'BEGIN'),
    'END': Token('END', 'END'),
    'TRUE': Token(BOOLEAN, True),
    'FALSE': Token(BOOLEAN, False),
    'AND': Token('AND', 'AND'),
    'OR': Token('OR', 'OR'),
    'NOT': Token('NOT', 'NOT'),
    'IF': Token('IF', 'IF'),
    'THEN': Token('THEN', 'THEN'),
    'ELSE': Token('ELSE', 'ELSE'),
    'ELIF': Token('ELIF', 'ELIF'),
    'FUNC': Token('FUNC', 'FUNC'),
}


class Lexer(object):
    def __init__(self, text):
        # client string input, e.g. "4 + 2 * 3 - 6 / 2"
        self.text = text
        # self.pos is an index into self.text
        self.pos = 0
        self.current_char = self.text[self.pos]

    def error(self):
        raise Exception('Invalid character')

    def peek(self):
        peek_pos = self.pos + 1
        if peek_pos > len(self.text) - 1:
            return None
        else:
            return self.text[peek_pos]

    def _id(self):
        """Handle identifiers and reserved keywords"""
        result = ''
        while self.current_char is not None and self.current_char.isalpha():
            result += self.current_char.upper()
            self.advance()

        token = RESERVED_KEYWORDS.get(result, Token(ID, result))
        return token

    def advance(self):
        """Advance the pos pointer and set the current_char variable."""
        self.pos += 1
        if self.pos > len(self.text) - 1:
            self.current_char = None  # Indicates end of input
        else:
            self.current_char = self.text[self.pos]

    def skip_whitespace(self):
        while self.current_char is not None and self.current_char.isspace():
            self.advance()

    def integer(self):
        """Return a (multidigit) integer consumed from the input."""
        result = ''
        while self.current_char is not None and self.current_char.isdigit():
            result += self.current_char
            self.advance()
        return int(result)

    def get_next_token(self):
        """Lexical analyzer (also known as scanner or tokenizer)

        This method is responsible for breaking a sentence
        apart into tokens. One token at a time.
        """
        while self.current_char is not None:

            if self.current_char.isspace():
                self.skip_whitespace()
                continue

            if self.current_char.isdigit():
                return Token(INTEGER, self.integer())

            if self.current_char.isalpha():
                return self._id()

            if self.current_char == '+':
                self.advance()
                return Token(PLUS, '+')

            if self.current_char == '-':
                self.advance()
                return Token(MINUS, '-')

            if self.current_char == '*':
                self.advance()
                return Token(MUL, '*')

            if self.current_char == '/':
                self.advance()
                return Token(DIV, '/')

            if self.current_char == '%':
                self.advance()
                return Token(MOD, '%')

            if self.current_char == '(':
                self.advance()
                return Token(LPAREN, '(')

            if self.current_char == '=':
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    return Token(ID, 'EQ')
                else:
                    self.error()

            if self.current_char == '!':
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    return Token(ID, 'NEQ')
                else:
                    self.error()

            if self.current_char == '>':
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    return Token(ID, 'GTE')
                else:
                    return Token(ID, 'GT')

            if self.current_char == '<':
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    return Token(ID, 'LTE')
                else:
                    return Token(ID, 'LT')

            if self.current_char == ')':
                self.advance()
                return Token(RPAREN, ')')

            if self.current_char == ';':
                self.advance()
                return Token('SEMI', ';')

            if self.current_char == '{':
                self.advance()
                return Token(LBRACE, '{')

            if self.current_char == '}':
                self.advance()
                return Token(RBRACE, '}')
            if self.current_char == ',':
                self.advance()
                return Token(COMMA, ',')

            self.error()

        return Token(EOF, None)


###############################################################################
#                                                                             #
#  PARSER                                                                     #
#                                                                             #
###############################################################################

class AST(object):
    pass


class BinOp(AST):
    def __init__(self, left, op, right):
        self.left = left
        self.token = self.op = op
        self.right = right


class Num(AST):
    def __init__(self, token):
        self.token = token
        self.value = token.value


class If(AST):
    def __init__(self, condition, true_block, elif_blocks, false_block):
        self.condition = condition
        self.true_block = true_block
        self.elif_blocks = elif_blocks if elif_blocks is not None else []
        self.false_block = false_block


class FunctionDeclaration(AST):
    def __init__(self, name, params, block):
        self.name = name
        self.params = params
        self.block = block


class FunctionCall(AST):
    def __init__(self, name, args):
        self.name = name
        self.args = args


class Parser(object):
    def __init__(self, lexer):
        self.lexer = lexer
        # set current token to the first token taken from the input
        self.current_token = self.lexer.get_next_token()

    def getBlock(self):
        result = ''
        while self.current_token.type != RBRACE:
            result = result + str(self.current_token.value)
            self.eat(self.current_token.type)

        return result

    def error(self):
        raise Exception('Invalid syntax')

    def eat(self, token_type):
        # compare the current token type with the passed token
        # type and if they match then "eat" the current token
        # and assign the next token to the self.current_token,
        # otherwise raise an exception.
        if self.current_token.type == token_type:
            self.current_token = self.lexer.get_next_token()
        else:
            self.error()

    def factor(self):
        """factor : INTEGER | BOOLEAN | LPAREN expr RPAREN"""
        token = self.current_token
        if token.type == INTEGER:
            self.eat(INTEGER)
            return Num(token)
        elif token.type == BOOLEAN:
            self.eat(BOOLEAN)
            return Num(token)
        elif token.type == LPAREN:
            self.eat(LPAREN)
            node = self.boolean_expr()
            self.eat(RPAREN)
            return node
        else:
            self.error()

    def term(self):
        """term : factor ((MUL | DIV) factor)*"""
        node = self.factor()

        while self.current_token.type in (MUL, DIV, MOD):
            token = self.current_token
            if token.type == MUL:
                self.eat(MUL)
            elif token.type == DIV:
                self.eat(DIV)
            elif token.type == MOD:
                self.eat(MOD)

            node = BinOp(left=node, op=token, right=self.factor())

        return node

    def expr(self):

        node = self.term()

        while self.current_token.type in (PLUS, MINUS):
            token = self.current_token
            if token.type == PLUS:
                self.eat(PLUS)
            elif token.type == MINUS:
                self.eat(MINUS)

            node = BinOp(left=node, op=token, right=self.term())

        return node

    def comparison_expr(self):
        """comparison_expr : expr ((GT | LT) expr)*"""
        node = self.expr()

        while self.current_token.value in ('GT', 'LT', 'EQ', 'NEQ', 'GTE', 'LTE'):
            token = self.current_token
            if token.value == GT:
                self.eat(ID)
            elif token.value == LT:
                self.eat(ID)
            elif token.value == 'EQ':
                self.eat('ID')
            elif token.value == 'NEQ':
                self.eat('ID')
            elif token.value == 'GTE':
                self.eat('ID')
            elif token.value == 'LTE':
                self.eat('ID')

            node = BinOp(left=node, op=token, right=self.expr())

        return node

    def boolean_expr(self):
        """boolean_expr : comparison_expr ((AND | OR) comparison_expr)*"""
        node = self.comparison_expr()

        while self.current_token.type in ('AND', 'OR'):
            token = self.current_token
            if token.type == 'AND':
                self.eat('AND')
            elif token.type == 'OR':
                self.eat('OR')

            node = BinOp(left=node, op=token, right=self.comparison_expr())

        return node

    def statement(self):
        """statement : boolean_expr SEMI"""
        if self.current_token.type == 'IF':
            return self.if_statement()
        else:
            node = self.boolean_expr()
            if self.current_token.type == 'SEMI':
                self.eat('SEMI')
            else:
                self.error()
        return node

    def peek(self):

        current_pos = self.lexer.pos
        current_char = self.lexer.current_char

        self.lexer.advance()
        next_token = self.lexer.get_next_token()

        #restore former position

        self.lexer.pos = current_pos
        self.lexer.current_char = current_char

        return next_token

    def statement_list(self):
        statements = []

        while self.current_token.type not in (RBRACE, EOF):
            if self.current_token.type == 'IF':
                statements.append(self.if_statement())
            elif self.current_token.type == 'FUNC':
                statements.append(self.function_declaration())
            elif self.current_token.type == 'ID' and self.lexer.current_char == LPAREN:
                statements.append(self.function_call())
            elif self.current_token.type == LBRACE:
                statements.append(self.block())
            else:
                statements.append(self.statement())

        return statements

    def block(self):
        """block : LBRACE statement_list RBRACE"""
        self.eat(LBRACE)
        statements = self.statement_list()
        self.eat(RBRACE)
        return statements

    def if_statement(self):
        """if_statement : IF boolean_expr THEN statement (ELSE statement)?"""
        self.eat('IF')
        condition = self.boolean_expr()
        self.eat('THEN')
        true_block = self.block()

        elif_blocks = []
        while self.current_token.type == 'ELIF':
            self.eat('ELIF')
            elif_condition = self.boolean_expr()
            self.eat('THEN')
            elif_block = self.block()
            elif_blocks.append((elif_condition, elif_block))
        false_block = None
        if self.current_token.type == 'ELSE':
            self.eat('ELSE')
            false_block = self.block()

        return If(condition, true_block, elif_blocks, false_block)

    def parameter_list(self):
        """formal_parameter_list : ID (COMMA ID)*"""
        params = []
        if self.current_token.type == ID:
            params.append(self.current_token.value)
            self.eat(ID)

        while self.current_token.type == COMMA:
            self.eat(COMMA)
            params.append(self.current_token.value)
            self.eat(ID)

        return params

    def function_declaration(self):
        """function_declaration : FUNCTION id LPAREN parameter_list RPAREN block"""
        self.eat('FUNC')
        func_name = self.current_token.value
        self.eat(ID)
        self.eat(LPAREN)
        parameters = self.parameter_list()
        self.eat(RPAREN)
        block = self.getBlock()
        return FunctionDeclaration(func_name, parameters, block)

    def argument_list(self):
        """argument_list : expr (COMMA expr)*"""
        args = []
        if self.current_token.type != RPAREN:
            args.append(self.boolean_expr())

        while self.current_token.type == COMMA:
            self.eat(COMMA)
            args.append(self.boolean_expr())

        return args

    def function_call(self):
        """function_call : ID LPAREN argument_list RPAREN"""
        name = self.current_token.value
        self.eat(ID)
        self.eat(LPAREN)
        args = self.argument_list()
        self.eat(RPAREN)
        return FunctionCall(name, args)

    def parse(self):
        return self.statement_list()


###############################################################################
#                                                                             #
#  INTERPRETER                                                                #
#                                                                             #
###############################################################################

class NodeVisitor(object):
    def visit(self, node):

        if isinstance(node, list):
            results = []
            for statement in node:
                result = self.visit(statement)
                if result is not None:
                    results.append(result)
            return results
        # במקרה אחר, נמשיך לבקר כרגיל
        method_name = 'visit_' + type(node).__name__
        visitor = getattr(self, method_name, self.generic_visit)
        return visitor(node)

    def generic_visit(self, node):
        raise Exception('No visit_{} method'.format(type(node).__name__))


class Interpreter(NodeVisitor):
    def __init__(self, parser):
        self.parser = parser
        self.function_table = function_table;

    def visit_BinOp(self, node):
        if node.op.type == PLUS:
            return self.visit(node.left) + self.visit(node.right)
        elif node.op.type == MINUS:
            return self.visit(node.left) - self.visit(node.right)
        elif node.op.type == MUL:
            return self.visit(node.left) * self.visit(node.right)
        elif node.op.type == DIV:
            return int(self.visit(node.left) / self.visit(node.right))
        elif node.op.type == MOD:
            return self.visit(node.left) % self.visit(node.right)
        elif node.op.value == GT:
            return self.visit(node.left) > self.visit(node.right)
        elif node.op.value == LT:
            return self.visit(node.left) < self.visit(node.right)
        elif node.op.value == 'EQ':
            return self.visit(node.left) == self.visit(node.right)
        elif node.op.value == 'NEQ':
            return self.visit(node.left) != self.visit(node.right)
        elif node.op.value == 'GTE':
            return self.visit(node.left) >= self.visit(node.right)
        elif node.op.value == 'LTE':
            return self.visit(node.left) <= self.visit(node.right)
        elif node.op.value == 'AND':
            return self.visit(node.left) and self.visit(node.right)
        elif node.op.value == 'OR':
            return self.visit(node.left) or self.visit(node.right)

    def visit_Num(self, node):
        return node.value

    def visit_If(self, node):
        if self.visit(node.condition):
            return self.visit(node.true_block)
        for elif_condition, elif_block in node.elif_blocks:
            if self.visit(elif_condition):
                return self.visit(elif_block)
        if node.false_block:
            return self.visit(node.false_block)

    def visit_FunctionDeclaration(self, node):

        # save function to (interpreter's) memory
        self.function_table[node.name] = node

    def visit_FunctionCall(self, node):
        function = self.function_table.get(node.name)
        params = function.params
        args = node.args

        result_string = function.block
        for param, arg in zip(params, args):
            strparam = str(param)
            strarg = str(self.visit(arg))
            result_string = re.sub(r'\b'+strparam+r'\b', strarg, result_string)
            result_string += '}'

        lex = Lexer(result_string)
        pars = Parser(lex)
        inter = Interpreter(pars)
        res = inter.interpret()
        for r in res:
            print(r)

    def interpret(self):
        tree = self.parser.parse()
        return self.visit(tree)


def main():
    while True:
        try:
            try:
                text = input('spi> ')
            except NameError:  # Python3
                text = input('spi> ')
        except EOFError:
            break
        if not text:
            continue
        # try:
        lexer = Lexer(text)
        parser = Parser(lexer)
        interpreter = Interpreter(parser)
        result = interpreter.interpret()
        for res in result:
            print(res)
    # except Exception as e:
    #    print(f"Error: {e}")


if __name__ == '__main__':
    main()

'''<program> ::= <statement_list>

<statement_list> ::= <statement> (<statement>)*

<statement> ::= <if_statement> | <boolean_expression> ";" | <block>

<if_statement> ::= "IF" <boolean_expression> "THEN" <block> (<elif_block>)* [ "ELSE" <block> ]

<elif_block> ::= "ELIF" <boolean_expression> "THEN" <block>

<block> ::= "{" <statement_list> "}"

<boolean_expression> ::= <comparison> | <boolean_expression> "AND" <boolean_expression> | <boolean_expression> "OR" <boolean_expression>

<comparison> ::= <expression> ">" <expression> 
               | <expression> "<" <expression> 
               | <expression> "==" <expression> 
               | <expression> "!=" <expression> 
               | <expression> ">=" <expression> 
               | <expression> "<=" <expression>

<expression> ::= <term> | <expression> "+" <term> | <expression> "-" <term>

<term> ::= <factor> | <term> "*" <factor> | <term> "/" <factor>

<factor> ::= <integer> | "(" <expression> ")"

<integer> ::= [0-9]+
'''